﻿var XSD
var XML

/* Map Object
map
{
	xmlNode = {}
	xsdNode = {}
	xsdAuxNode = {} //Узел для продвижения по xsd	
	parent = {}
	number = 0 //номе тега согласно xpath. только для тегов	
	choice = true //true - под этим узлом выбираются элементы из choice
}
*/


// Список поддерживаемых деклараций объект типа SupportedDecl[knd, versForm] 
SupportedDecl = 
{
	"0710099": 
	{
		declName: "Бухгалтерская отчетность",
		versForm: {
					"5.05": { xsdFileName: "NO_BUHOTCH_1_105_00_05_05_01.xsd" }, 
					"5.07": { xsdFileName: "NO_BUHOTCH_1_105_00_05_07_01.xsd" },
				  },
	},
	"0000080": 
	{
		declName: "Книга покупок",
		versForm: {
				"5.05": { xsdFileName: "NO_NDS.8_1_003_01_05_05_02.xsd" },
				"5.06": { xsdFileName: "NO_NDS.8_1_003_01_05_06_02.xsd" },   
			  
			  }, 		
	},
	"0000090": 
	{
		declName: "Книга продаж",
		versForm: {
				"5.05": { xsdFileName: "NO_NDS.9_1_003_03_05_05_01.xsd" },
				"5.06": { xsdFileName: "NO_NDS.9_1_003_03_05_06_01.xsd" },
		}, 		
	},
	"1151001": 
	{
		declName: "Налоговая декларация по налогу на добавленную стоимость",
		versForm: {
				"5.05": { xsdFileName: "NO_NDS_1_003_00_05_05_02.xsd" },
				"5.06": { xsdFileName: "NO_NDS_1_003_00_05_06_02.xsd"},
			}, 		
	},
	"1151099": 
	{
		declName: "6-НДФЛ",
		versForm: {
					"5.01": { xsdFileName: "NO_NDFL6_1_152_00_05_01_02.xsd" },
					"5.02": { xsdFileName: "NO_NDFL6_1_152_00_05_02_02.xsd" },
				}, 		
	},
	"1151006": 
	{
		declName: "Налоговая декларация на прибыль организации",
		versForm: {"5.07": { xsdFileName: "NO_PRIB_1_002_00_05_07_04.xsd" },}, 		
	},	
	"1151078":
	{
		declName: "2-НДФЛ",
		versForm: {
				"5.04": { xsdFileName: "NO_NDFL2_1_399_00_05_04_01.xsd" },
				"5.06": { xsdFileName: "NO_NDFL2_1_399_00_05_06_01.xsd" },			
				}, 
	},
	"1151111": 
	{
		declName: "Расчет по страховым взносам",
		versForm: {"5.01": { xsdFileName: "NO_RASCHSV_1_162_00_05_01_03.xsd" },}, 		
	},
	"1152016":
	{
		declName: "Налоговая декларация по единому налогу на вмененный доход для отдельных видов деятельности",
		versForm: {"5.03": { xsdFileName: "NO_ENVD_1_029_00_05_07_01.xsd"},}, 		
	},
	"1152017": 
	{
		declName: "Налоговая декларация по налогу, уплачиваемому в связи с применением упрощенной системы налогообложения",
		versForm: {"5.05": { xsdFileName: "NO_USN_1_030_00_05_05_01.xsd"},}, 		
	},
	"1153005":
	{
		declName: "Налоговая декларация по земельному налогу",
		versForm: {"5.03": { xsdFileName: "NO_ZEMND_1_075_00_05_03_02.xsd"},}, 		
	},	
}


function Start(strXml)
{	 
	XML = new DOMParser().parseFromString(strXml, 'text/xml');	
	if (XML.getElementsByTagName("parsererror").length>0)
	{
		document.getElementById('TaxInfo').innerHTML = "Файл не является правильным XML файлом"
		return;
	}
	
	var KND = GetSingleAttributeValue(XML, XML, "Файл/Документ/@КНД");
	if (!KND) KND = GetSingleAttributeValue(XML, XML, 'Файл/Документ/@Индекс');
	var nomKorr = GetSingleAttributeValue(XML, XML, 'Файл/Документ/@НомКорр');
	var year = GetSingleAttributeValue(XML, XML, 'Файл/Документ/@ОтчетГод');
	var period = GetSingleAttributeValue(XML, XML, 'Файл/Документ/@Период');
	var versForm = GetSingleAttributeValue(XML, XML, 'Файл/@ВерсФорм');
	var taxInfo = "Номер корректировки: " + nomKorr + ". Отчетный год: " + year +". Период: " + period + '. Версия формы: ' + versForm; 
	var xsdFileName = "";	
	
	// Выбор отчета по КНД
	if (!KND) 
	{
		Log("Не удалось получить КНД из файла");	
		return;
	}	
		
	if (!SupportedDecl[KND]) 		
	{
		Log("Документ с КНД = " + KND + " не поддерживается программой проверки");
		return;
	}
	
	// Выбор отчета по версии формы
	if (!versForm)
	{
		Log('У документа "' + SupportedDecl[KND].declName + '" не удалось получить версию формы из файла');	
		return;
	}
	if (!SupportedDecl[KND].versForm[versForm])
	{
		Log(SupportedDecl[KND].declName + " с версией формы " + versForm + " не поддерживается программой проверки");	
		return;
	}
	
	//Прописываем имя декларации в интерфейс
	document.getElementById('TaxInfo').innerHTML = SupportedDecl[KND].declName + ". " + taxInfo;
	
	//Загрузка xsd файла с сервера	
	 
	XSD = LoadXsdFromServer(SupportedDecl[KND].versForm[versForm].xsdFileName);
	if (XSD == null)
	{
		document.getElementById('TaxInfo').innerHTML = "Не удалось загрузить XSD cхему с сервера"
		return;
	}		
  
	var map = {elemName: "", xsdNode: XSD, xmlNode: XML}
	
	Traverse(XSD, map)
	if (document.getElementById('CheckResult').children.length == 0) Log("Ошибок не обнаружено")
}



function LoadXsdFromServer(xsdFileName)
{
	var xhr = new XMLHttpRequest();
	xhr.open('GET', "xsd/" + xsdFileName, false);	
	xhr.send();
	if (xhr.status = 200)	 
		return new DOMParser().parseFromString(xhr.responseText,'text/xml');
	return null	
}


function Log(message)
{
	var table = document.getElementById('CheckResult')
	var tr = document.createElement('tr')
	var td_count =  document.createElement('td');
	var td_errortext = document.createElement('td')
	td_count.innerHTML = table.children.length + 1
	td_errortext.innerHTML = message 
	tr.appendChild(td_count)
	tr.appendChild(td_errortext)
	table.appendChild(tr)
}


function Traverse(xsdNode,map)
{	
	switch (xsdNode.nodeName)
		{
			case "xs:element":					 
				var xmlNodes = GetNodes(XML, map.xmlNode, xsdNode.getAttribute("name"));
				var newMap = {};
				newMap.xsdNode = xsdNode
				newMap.parent = map;				
				CheckNodesCount(newMap, xmlNodes.length);			
				for (var j=0; j < xmlNodes.length; j++)
				{				
					var newMap = {}							
					newMap.xsdNode = xsdNode
					newMap.xmlNode = xmlNodes[j];
					newMap.number = j+1;
					newMap.parent = map;

					var checkSimpleTypeResult = CheckSimpleType(newMap); //получение текстового пояснения ошибки	
					if (checkSimpleTypeResult != "")	
					Log('Неверно заполнено поле <b>' + GetDescription(newMap) + ' = "' + newMap.xmlNode.textContent + '"</b>. Должно быть ' + checkSimpleTypeResult);	

					for (var i=0; i < xsdNode.children.length; i++)
					{
						var nextXsdNode = xsdNode.children[i];
						//Если новый элемент ссылается на глобальный тип, то на следующем шаге пойдем через него
						var typeName = newMap.xsdNode.getAttribute('type');
						if (typeName)
						{
							var typeNode = GetNodes(XSD, XSD,'/xs:schema/*[@name="' + typeName + '"]')[0];
							if (typeNode) nextXsdNode = typeNode
						}						
						Traverse(nextXsdNode, newMap);								
					}
					
				}	
			return;				

			case "xs:attribute":				
				var newMap = {};
				newMap.xsdNode = xsdNode;
				newMap.xmlNode = GetNodes(XML, map.xmlNode, "@" + xsdNode.getAttribute("name"))[0];				
				newMap.parent = map;				
				CheckAttribute(newMap);				
			return;
		
			case "xs:choice":	
				map.choice = true;
				CheckChoice(xsdNode, map);				
			break;		
			
			case "sch:assert":
				CheckTest(xsdNode, map);
			return;
			
			default:
				//Если на корневом уровне XSD не xs:element и есть атрибут name, то это глобальный тип. Там не обходим.				
				if (xsdNode.parentElement)
					if (xsdNode.getAttribute("name") && xsdNode.parentElement.nodeName == "xs:schema" && map.xsdNode == XSD)											
						return;
					
						
			break;						
		}
		
		//просто двигаемся по xsd	
		for (var i=0; i < xsdNode.children.length; i++)					
			Traverse(xsdNode.children[i], map);	
}

function GetDescription(map)
{
	if (document.getElementById("ExtraInfo").checked) return GetFullDescription(map);
	return GetShortDescription(map);	
}

function GetFullDescription(map)
{
	var auxMap = map;
	var description = "";
	while (auxMap.xsdNode != XSD)
	{
		var documentation = GetContent(XSD, auxMap.xsdNode,'xs:annotation/xs:documentation');
		var xmlnumber = '';
		if (auxMap.number) xmlnumber = "[" + auxMap.number + "]";		
		var arrow = '';
		if (auxMap.parent.xsdNode != XSD) arrow = " &rArr; ";
		var xmlNodeName = "";
		if (auxMap.xmlNode) xmlNodeName = "(" +  auxMap.xmlNode.nodeName + xmlnumber + ")"
			else xmlNodeName = "(" + auxMap.xsdNode.getAttribute("name") + ")";
		description = arrow + (documentation[0] || documentation[1]) + xmlNodeName + description;
		auxMap = auxMap.parent;	
	} 
	return description;
}

function GetShortDescription(map)
{
	var auxMap = map;
	var description = "";
	var firstIteration = true;
	while (auxMap.xsdNode != XSD)
	{
		var documentation = GetContent(XSD, auxMap.xsdNode,'xs:annotation/xs:documentation');
		var number = '';
		if (auxMap.number && auxMap.number != 1) number = "(" + auxMap.number + ")";
		var arrow = ''
		if (auxMap.parent.xsdNode != XSD && documentation[2] != "part") arrow = " &rArr; ";
		if (firstIteration) description = arrow + (documentation[0] || documentation[1]) + number;
		else if (documentation[0] != '') description =  arrow + documentation[0] + number + description;
		if (documentation[2] == "part") break;
		firstIteration = false;
		auxMap = auxMap.parent;	
		
	} 
	return description;
}


// Проверка узлов на количество
function CheckNodesCount(map, xmlOccurs)
{	
	
	//Максимальное вхождение
	var maxOccurs = map.xsdNode.getAttribute('maxOccurs');
	if (maxOccurs == 'unbounded') maxOccurs = 'Infinity'
		else if (!maxOccurs) maxOccurs = 1
				else maxOccurs = parseInt(maxOccurs);
	//Минимальное вхождение
	var minOccurs = map.xsdNode.getAttribute('minOccurs');
	if (!minOccurs) minOccurs = 1
		else minOccurs = parseInt(minOccurs);
	
    if (xmlOccurs > maxOccurs || (xmlOccurs < minOccurs && !map.parent.choice))
    {    
        var mustBe = '';     // Должно быть по количеству
        if (maxOccurs == minOccurs) mustBe = ' ровно ' + minOccurs
			else if (maxOccurs == 'Infinity') mustBe =' минимум ' + minOccurs
				else mustBe = ' от ' +  minOccurs + ' до ' + maxOccurs

        Log('<b>' +  GetDescription(map) + '</b> присутствует '  + xmlOccurs + ' раз. Должно быть ' + mustBe);
    }

}


function CheckAttribute(map)
{			
	//Проверить обязательность присутствия атрибута
	if (map.xsdNode.getAttribute("use") == 'required' && map.xmlNode == undefined)	
	{
		Log('Не заполнено обязательное поле <b>' + GetDescription(map) + '</b>');
		
	}	
	
	if (map.xmlNode == undefined) return;
	
	var use = '';
	if (map.xsdNode.getAttribute("use") == 'required') use = 'обязательное'
		else use = 'необязательное';			

	var checkSimpleTypeResult = CheckSimpleType(map); //получение текстового пояснения ошибки	
	if (checkSimpleTypeResult != "")	
		Log('Неверно заполнено ' + use + ' поле <b>' + GetDescription(map) + ' = "' + map.xmlNode.value + '"</b>. Должно быть ' + checkSimpleTypeResult);	
}


//Проверка аттрибутов и тегов с текстовым содержанием
//Успех - пустая строка. Ошибка - строка с пояснениями
function CheckSimpleType(map)
{		
	var typeName = map.xsdNode.getAttribute("type");
	var xmlValue = map.xmlNode.textContent;
	
	var restriction;
	
	// Если есть ссылка глобальный тип
	if (typeName) 
		restriction = GetNodes(XSD, XSD, 'xs:schema/xs:simpleType[@name="' + typeName + '"]/xs:restriction')[0]		
	else 	
		restriction = GetNodes(XSD, map.xsdNode, 'xs:simpleType/xs:restriction')[0]; // Нет ссылки на глобальный тип	
	
		
	//Строки для объяснения ограничений		
	var checkResult = true;	
	var baseText = "";
	var restrictionText = ""
	
	var baseType = typeName;
	if (restriction) baseType = restriction.getAttribute("base");
	
	
	// Проверка базового типа
		switch (baseType)
		{
			case 'xs:string': //не проверяем, т.к. тип и так всегда изначально string
				baseText = 'строкой'
				break

			case 'xs:integer':
				if (!CheckInt(xmlValue)) checkResult = false
				baseText = 'целым числом'
				break

			case 'xs:decimal':
				if (!CheckDecimal(xmlValue)) checkResult = false
				baseText = 'дробным числом  (дробная часть отделяется точкой)'
				break

			case 'xs:gYear':
				if (!CheckYear(xmlValue)) checkResult = false
				baseText = 'тремя цифрами. Например: 2014'
				break
		}
		//Проверка специфических ограничений (restriction).
	
		if (restriction)
		{			
			var length = GetSingleAttributeValue(XSD, restriction, "xs:length/@value");
			var minLength = GetSingleAttributeValue(XSD, restriction, "xs:minLength/@value");
			var maxLength = GetSingleAttributeValue(XSD, restriction, "xs:maxLength/@value");
			var totalDigits = GetSingleAttributeValue(XSD, restriction, "xs:totalDigits/@value");
			var fractionDigits = GetSingleAttributeValue(XSD, restriction, "xs:fractionDigits/@value");
			var patterns = GetAttributeValues(XSD, restriction, "xs:pattern/@value");
			var enumerations = GetAttributeValues(XSD, restriction, "xs:enumeration/@value");
			
			if (length)
				if (xmlValue.length != length)
				{
					checkResult = false
					restrictionText = ' длиной ' + length + ' cимволов'
				}
			if (minLength != "" && maxLength != "")
				if (xmlValue.length > maxLength || xmlValue.length < minLength)
				{
					checkResult = false
					restrictionText = ' длиной от ' + minLength + ' до ' + maxLength + ' символов'
				}
			if (maxLength != "" && minLength == "")
				if (xmlValue.length > maxLength)
				{
					checkResult = false
					restrictionText = ' длиной до ' + maxLength + ' символов'
				}
			if (maxLength == "" && minLength != "")
				if (xmlValue.length < minLength)
				{
					checkResult = false
					restrictionText = ' длиной от ' + minLength + ' символов'
				}
			if (totalDigits)
				if (xmlValue.length > parseInt(totalDigits) + 1)
				{
					checkResult = false
					restrictionText = ' общей длиной до ' + totalDigits + ' цифр '
				}
			if (fractionDigits)
			{
				var fraction = xmlValue.split('.')[1];			
				if (fraction) 					
					if (fraction.length > fractionDigits)				
					{
						checkResult = false
						restrictionText += ', c числом цифр в дробной части равным ' + fractionDigits + ' символов'
					}
			}
			if (patterns.length > 0)
			{
				var isOk = false;
				for (var i = 0; i < patterns.length; i++)
				{
					var r = new RegExp(patterns[i])
					if (r.test(xmlValue)) {isOk = true; break;} 	//Если соответствует хоть одному паттерну
				}
				if (!isOk)
				{
					checkResult = false;
					restrictionText = ' по определенному шаблону';
				}
			}
			if (enumerations.length > 0)
			{
				var isOk = false;
				var list = '';
				for (var i = 0; i<enumerations.length; i++)
				{
					if (xmlValue == enumerations[i]) isOk = true;
					list += ' ' + enumerations[i]	+ ',';
				}
				if (!isOk)
				{
					checkResult = false;
					list = list.slice(0,-1);
					restrictionText = ' из списка значений:' + list;
					baseText = ''; // информацию о базовом типе не будем выводить, т.к. и так есть список значений
				}
			}

		}
		
	if (checkResult) return "";
	return baseText + restrictionText;
}

function CheckTest(assertXsdNode, map)
{	
	var strTest = assertXsdNode.getAttribute("test").trim();
	var result = {};
	if (strTest.startsWith("usch:iif"))
	{			
		var arrTest = strTest.split(",");
		arrTest[0] = arrTest[0].trim().splice(0,8).trim().splice(0,1); // удаляем лишние скобки от iif
		arrTest[2] = arrTest[2].trim().splice(-1,1);
		result = XML.evaluate(arrTest[0], map.xmlNode, NSResolver, XPathResult.BOOLEAN_TYPE, null);
		if (result.booleanValue) result = XML.evaluate(arrTest[1], map.xmlNode, NSResolver, XPathResult.BOOLEAN_TYPE, null)
			else result = XML.evaluate(arrTest[2], map.xmlNode, NSResolver, XPathResult.BOOLEAN_TYPE, null)
	}
	else if (strTest.startsWith("usch:getFileName()"))
	{
		var arrTest = strTest.split("=");
		var fileName = document.getElementById('file').files[0].name.splice(-4,4);
		result.booleanValue = (GetSingleAttributeValue(XML, XML, "Файл/@ИдФайл") == fileName);

	}
	else result = XML.evaluate(strTest, map.xmlNode, NSResolver, XPathResult.BOOLEAN_TYPE, null);
	
	if (!result.booleanValue) Log(GetDescription(map) + ". " + GetContent(XSD, assertXsdNode, "usch:error"));
}


function CheckChoice(choiceXsdNode, map)
{	
	var required = [];
	var occurs = [];
	for (var i=0; i<choiceXsdNode.children.length; i++)
	{
		if (choiceXsdNode.children[i].nodeName == "xs:element")
		{
			var xmlNodes = GetNodes(XML, map.xmlNode, choiceXsdNode.children[i].getAttribute("name"));
			if (xmlNodes.length > 0) occurs.push([choiceXsdNode.children[i]]);//есть в xml
			
			//Минимальное вхождение
			var minOccurs =	choiceXsdNode.children[i].getAttribute('minOccurs');
			if (!minOccurs) minOccurs = 1; else minOccurs = parseInt(minOccurs);			
			if (minOccurs >= 1) required.push([choiceXsdNode.children[i]]); //должно быть в xml
		}
		else
		{
			var xsdElems = GetChildXsdElements(choiceXsdNode);			
			var auxArray1 = [];
			var auxArray2 = [];
			for (var j=0; j<xsdElems.length; j++)
			{
				var xmlNodes = GetNodes(XML, map.xmlNode, xsdElems[j].getAttribute("name"));
				if (xmlNodes.length > 0) auxArray2.push(xsdElems[j]);//есть в xml
			
				var minOccurs =	xsdElems[j].getAttribute('minOccurs');
				if (!minOccurs) minOccurs = 1; else minOccurs = parseInt(minOccurs);			
				if (minOccurs >= 1) auxArray1.push(xsdElems[j]); //должно быть в xml
				
			}
			if (auxArray1.length > 0) required.push(auxArray1);
			if (auxArray2.length > 0) occurs.push(auxArray2);
		}
	}
	
	if (occurs.length > 1)
	{
		var names = "";
		for (var i=0; i<occurs.length; i++)
		{		
			for (var j=0; j<occurs[i].length; j++)
			{			
				var documentation = GetContent(XSD, occurs[i][j], 'xs:annotation/xs:documentation');		
				names += (documentation[0] || documentation[1]);
				if (j != occurs[i].length-1) names += ", ";
			}
			if (i != occurs.length-1) names += " и ";
		}
		
		Log('<b>' + GetDescription(map) + "</b>. Обнаружено одновременное заполнение: " + names);
	}
	
	if (occurs.length <= 0)
	{
		var names = "";
		for (var i=0; i<required.length; i++)
		{		
			for (var j=0; j<required[i].length; j++)
			{			
				var documentation = GetContent(XSD, required[i][j], 'xs:annotation/xs:documentation');		
				names += (documentation[0] || documentation[1]);
				if (j != required[i].length-1) names += ", ";
			}
			if (i != required.length-1) names += " или ";
		}
		Log('<b>' + GetDescription(map) + "</b>. Не заполнен один из обязательных разделов: " + names);
	}
}
//========================================================================================================	===============================================================

function ShowResult()
{
	var mapping = {obj: Objects[0], parentMap: null};	
	var queue = [mapping];
	var select = document.getElementById("xpath_select");
	while (select.firstChild) select.firstChild.remove();
	while (queue.length > 0)
	{
		var map = queue.shift();
		//Выводим в лист
		var m = map;
		var xpath = ''
		while(m)
		{
			xpath = m.obj.name + '/' + xpath;
			m = m.parentMap;
		}
		xpath = xpath.slice(0,-1);
		select.options[select.options.length] = new Option(Objects.indexOf(map.obj) + ' | ' + xpath);
		for (var i in map.obj.childrenId)
		{
			var childObj = Objects[map.obj.childrenId[i]];			
			var newMap = {obj: childObj, parentMap: map}
			queue.push(newMap);
		}
	}
	document.getElementById('result').value = FileID + ' =\r\n';
	document.getElementById('result').value += JSON.stringify(Objects,null,1)
	document.getElementById('result').value += selfCheckText;	
	
}


function NSResolver(nsPrefix)
{
	if (nsPrefix == 'xs') return 'http://www.w3.org/2001/XMLSchema'
	else if (nsPrefix == 'sch') return 'http://purl.oclc.org/dsdl/schematron'
	else if (nsPrefix == 'usch') return 'http://www.unisoftware.ru/schematron-extensions';
	return null;
}


function GetNodes(Doc, parentNode, xpath)
{	 	
	var nodesSnapshot = Doc.evaluate(xpath, parentNode, NSResolver, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null)
	var nodes = []
	for (var i=0;i<nodesSnapshot.snapshotLength;i++) nodes[i] = nodesSnapshot.snapshotItem(i)
	return nodes;
}


function GetSingleAttributeValue(Doc, parentNode, xpath)
{	 
	var nodesSnapshot = Doc.evaluate(xpath, parentNode, NSResolver, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null)
	var attr = nodesSnapshot.snapshotItem(0)
	if (attr) return attr.value;
	return "";	
}


function GetAttributeValues(Doc, parentNode, xpath)
{
	var nodesSnapshot = Doc.evaluate(xpath, parentNode, NSResolver, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null)
	var values = []
	for (var i=0;i<nodesSnapshot.snapshotLength;i++) values[i] = nodesSnapshot.snapshotItem(i).value
	return values;
}

function GetContent(Doc, parentNode,xpath)
{	 
	var nodesSnapshot = Doc.evaluate(xpath, parentNode, NSResolver, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null)
	var content = []
	for (var i=0;i<nodesSnapshot.snapshotLength;i++) content[i] = nodesSnapshot.snapshotItem(i).innerHTML
	return content;
}


function SelectChanged()
{
	var select = document.getElementById("xpath_select");
	var selectedIndex = select.selectedOptions[0].text.split('|')[0].trim();
	var obj = Objects[selectedIndex];
	
	document.getElementById('selected').value = "";
	document.getElementById('selected').value = JSON.stringify(obj,null,1);
}


function CheckInt(value)
{
	if (value == null) return false
	value = value / 1
	return parseInt(value) === value
}


function CheckYear(value)
{
	if (value == null) return false
	if (value.length != 4) return false
	var r = new RegExp('[0-9]{4}')
	if (r.test(value)) return true
	else return false
}


function CheckDecimal(value)
{
	if (value == null) return false
	var p = 0
	for (var i = 0; i < value.length; i++)
	{
		if (value[i] == '.') p++
		if (!( value[i]/1 === parseInt(value[i])) && value[i] != '.') return false
	}

	if (p > 1) return false //если точек больше одной
	return true
}


function GetChildXsdElements(xsdNode)
{	
	var result = [];
	for (var i=0; i<xsdNode.children.length; i++)		
		if (xsdNode.children[i].nodeName == 'xs:element') 
			result.push(xsdNode.children[i])		
			else result = result.concat(GetChildElements(xsdNode.children[i]));	
	
	
	//Если есть глобальный тип, то заходим в него
	var typeName = node.getAttribute('type');
	if (typeName)
	{
		var typeNode = GetNodes(XSD,'xs:schema/*[@name="' + typeName + '"]')[0];
		if (typeNode) result = result.concat(GetChildXsdElements(typeNode));
	}	
	
	return result;			
}

String.prototype.splice = function (start, count, elems) {
    var arr = this.split('');
    arr.splice.apply(arr, arguments);
    return arr.join('');

}
